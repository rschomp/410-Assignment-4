package SPLT_A4;

public class BST_Node {
	String data;
	BST_Node left;
	BST_Node right;
	BST_Node par; //parent...not necessarily required, but can be useful in splay tree
	boolean justMade; //could be helpful if you change some of the return types on your BST_Node insert.
	            //I personally use it to indicate to my SPLT insert whether or not we increment size.
	
	BST_Node(String data){
		this.data=data;
		 this.justMade=true;
	}
	
	BST_Node(String data, BST_Node left,BST_Node right,BST_Node par){ //feel free to modify this constructor to suit your needs
		    this.data=data;
		    this.left=left;
		    this.right=right;
		    this.par=par;
		    this.justMade=true;
	}
	
	public String getData(){
		return data;
	}
	public BST_Node getLeft(){
		return left;
	}
	public BST_Node getRight(){
		return right;
	}
	
	public BST_Node containsNode(String s){
		if(this.data.equals(s)){
			splay(this);
			return this;
		}
		else if(data.compareTo(s)>0){//s lexiconically less than data
			if(left==null){
				splay(this);
				return this;
			}
			return left.containsNode(s);
		}
		else if (data.compareTo(s)<0){
			if(right==null){
				splay(this);
				return this;
			}
			return right.containsNode(s);
		}
		return null; //shouldn't hit
	}
	public BST_Node insertNode(String s){
		if(data.compareTo(s)>0){
			if(left==null){
				left=new BST_Node(s);
				this.justMade = true;
				this.left.par = this;
				BST_Node tempVar = this.left;
				splay(this.left);
				return tempVar;
			}
			return left.insertNode(s);
		}
		if(data.compareTo(s)<0){
			if(right==null){
				right=new BST_Node(s);
				this.justMade = true;
				this.right.par = this;
				BST_Node tempVar = this.right;
				splay(this.right);
				return tempVar;
			}
			return right.insertNode(s);
		}
		if (this.data.equals(s)){
			this.justMade = false;
			splay(this);
			return(this);
			
			//return null;//ie we have a duplicate
		}
		
		return null;
	}
	public BST_Node findMin(){
		if(left!=null){
			return left.findMin();
		}
		splay(this);
		return this;
	}
	public BST_Node findMax(){
		if(right!=null){
			return right.findMax();
		}
		splay(this);
		return this;
	}
	public int getHeight(){
		int l=0;
		int r=0;
		if(left!=null)l+=left.getHeight()+1;
		if(right!=null)r+=right.getHeight()+1;
		return Integer.max(l, r);
	}
	public String toString(){
		return "Data: "+this.data+", Left: " + ((this.left!=null)?left.data:"null")+",Right: "+((this.right!=null)?right.data:"null");
	}
	
	private void rotateLeft (BST_Node splay) {
	    BST_Node tempVar = splay.par;
	    splay.par.right = splay.left;
	    
	    if (splay.left != null){
	    	splay.left.par = splay.par;
	    }
	    if (splay.par.par != null){
	    	if (tempVar != tempVar.par.left){
	    		splay.par.par.right = splay;
	    		splay.par = tempVar.par;
	    		
	    	}
	    	else{
	    		splay.par.par.left = splay;
	    		splay.par = tempVar.par;
	    	}
	    }
	    else{
	    	splay.par = null;
	    }
	    splay.left = tempVar;
	    splay.left.par = splay;
	}

	
	private void rotateRight (BST_Node splay) {

    BST_Node tempVar = splay.par;
	    
	    splay.par.left = splay.right;
	    if (splay.right != null){
	    	splay.right.par = splay.par;
	    }
	    if (splay.par.par != null){
	    	if (tempVar != tempVar.par.right){
	    		splay.par.par.left = splay;
	    		splay.par = tempVar.par;
	    		
	    	}
	    	else{
	    		splay.par.par.right = splay;
	    		splay.par = tempVar.par;
	    	}
	    }
	    else{
	    	splay.par = null;
	    }
	    splay.right = tempVar;
	    splay.right.par = splay;

	}
	
	public void splay(BST_Node toSplay) { 
		while(toSplay.par != null){
			BST_Node Parent = toSplay.par;
			BST_Node GrandParent = Parent.par;
			if (GrandParent == null){
				if (toSplay == Parent.right){
					rotateLeft(toSplay);
				}
				else {rotateRight(toSplay);}
			}
			else {
				if (toSplay == Parent.left){
					if (toSplay.par == GrandParent.left){
						rotateRight(toSplay);
						rotateRight(toSplay);
					}
					else {
						rotateRight(toSplay);
						rotateLeft(toSplay);
					}
				}
				else {
					if(Parent == GrandParent.right){
						rotateLeft(toSplay);
						rotateLeft(toSplay);
						
					}
					else{
						rotateLeft(toSplay);
						rotateRight(toSplay);
					}
				}
			}
		}
	} 
	//you could have this return or take in whatever you want..so long as it will do the job internally. As a caller of SPLT functions, I should really have no idea if you are "splaying or not"
    //I of course, will be checking with tests and by eye to make sure you are indeed splaying
    //Pro tip: Making individual methods for rotateLeft and rotateRight might be a good idea!
	
}
