package SPLT_A4;

public class SPLT implements SPLT_Interface{
  private BST_Node root;
  private int size;
  
  public SPLT() {
    this.size = 0;
  } 
  
  public BST_Node getRoot() { //please keep this in here! I need your root node to test your tree!
    return root;
  }

@Override
public void insert(String s) {
	if (root == null){
		BST_Node anotherNode = new BST_Node(s);
		root = anotherNode;
		size++;
	}
	else{
		root = root.insertNode(s);
		if (root.justMade){
		size++;
		}
	}
}

@Override
public void remove(String s) {
	boolean conBoo = contains(s);
	if(conBoo){
		if (root.right == null && root.left == null){ 
			root = null;
			size = 0;
		}
		if (size ==1){
			root = null;
		}
		else if(root.left == null){
			BST_Node L = root.left;
			BST_Node R = root.right;
			root.right.par = null;
			root = null;
			root = R.findMin();
			root.left = L;
			
			if(root.left != null){
				root.left.par = root;
			}
		}else{
			BST_Node L = root.left;
			BST_Node R = root.right;
			root.left.par = null;
			
			if (root.right != null){
				root.right.par = null;
			}
			root = null;
			root = L.findMax();
			root.right = R;
			
			if (root.right != null){
				root.right.par = root;
			}
		}
		size--;
	}
}
			
		/*
	//if (root.left.right == null){
		//root = root.left;
	//}
	
	BST_Node L = root.left;
	BST_Node R = root.right;
	L.par = null;
	R.par = null;
	
	root = L.findMax();
	root.right = R;
	R.par = root;
	L.par = root;
	size--;
	
	*/


@Override
public String findMin() {
	if (size == 0){
		return null;
	}
	else{
		root = root.findMin();
		return root.data;
	}
	
}

@Override
public String findMax() {
	if (size == 0){
		return null;
	}
	else{
		root = root.findMax();
		return root.data;
	}
	
}

@Override
public boolean empty() {
	if (size() == 0){
		return true;
	}
	else {return false;}
}

@Override
public boolean contains(String s) {
	if (empty()){
		return false;
	}
	if (root != null) {
		root = root.containsNode(s); 
		return root.data.equals(s);
	}
	else {return false;}
	
}

@Override
public int size() {
	return size;
}

@Override
public int height() {
	if (root == null){
		return -1;
	}
	if (root.right == null && root.left == null){
		  return 0;
	  }
	else {return root.getHeight();}
}  

}
